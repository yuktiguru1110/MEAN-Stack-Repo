//Task 9 : Using Node js add one new field as "Salary" 
//& Insert the Salary for all customers

var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/";
MongoClient.connect(url, function(err, db) 
      {  if (err) throw err;  
         var dbo = db.db("mydb2"); 
        var query={};
        var values={ $set: { salary: 5000 } };
        
         dbo.collection("customers").updateMany(query,values,function(err, res) 
         {    if (err) throw err;    
              console.log(res.result.nModified);
             
              db.close();  
         });
});