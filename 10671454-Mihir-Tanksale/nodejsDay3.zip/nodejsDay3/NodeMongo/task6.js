/*
a) Using NodeJs Show All Database existing inside the MongoDB 
b) Show All Collection existing inside the mydb database 
c) Show Number Of Documents existing inside the Customers collections 
d) Show All records of Customers & Sort the result alphabetically by name
*/
//////////////////////////////////////////////////////////////////////////////
/*
var mongoClient = require('mongodb').MongoClient;
var dbName = 'test';
mongoClient.connect("mongodb://localhost/",
{useUnifiedTopology: true,useNewUrlParser:true, poolSize: 5, reconnectInterval: 500 },
function(err,client){
    var dbAdmin=client.db(dbName).admin();
dbAdmin.listDatabases(function (err,databases) {
    console.log("before adding databases");
    console.log(databases);
    client.close();
})
});
*/
////////////////////////////////////////////////////////////////////////////
/*
var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/";

MongoClient.connect(url, function(err, db) {
  if (err) throw err;
  var dbo = db.db("mydb2");
  dbo.listCollections().toArray(function(err, result) {
    if (err) throw err;
    console.log(result);
    db.close();
  });
});
*/
//////////////////////////////////////////////////////////////////////////////////
/*
var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/";

MongoClient.connect(url, function(err, db) {
  if (err) throw err;
  var dbo = db.db("mydb2");
  dbo.collection("customers").aggregate([ { $count: "mycount" }]).toArray(function(err, result) {
    if (err) throw err;
    console.log(result);
    db.close();
  });
});
*/

//////////////////////////////////////////////////////////////////////
var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/";

MongoClient.connect(url, function(err, db) {
  if (err) throw err;
  var dbo = db.db("mydb2");
  var mysort = { name: 1 };
  dbo.collection("customers").find().sort(mysort).toArray(function(err, result) {
    if (err) throw err;
    console.log(result);
    db.close();
  });
});