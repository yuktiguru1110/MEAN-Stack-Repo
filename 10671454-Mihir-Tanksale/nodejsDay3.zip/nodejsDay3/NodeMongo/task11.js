//Using NodeJS create a new collection tempcollection & drop the Collection tempcollection
var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/";
/*MongoClient.connect(url, function(err, db) {  
    if (err) throw err;  
    var dbo = db.db("mydb2");  
    dbo.createCollection("temp", function(err, res) {    
        if (err) throw err;    
        console.log("temp Collection created!");    
        db.close();  
    });
});*/

MongoClient.connect(url, function(err, db) {  
    if (err) throw err;  
    var dbo = db.db("mydb2");  
    dbo.dropCollection("temp", function(err, res){
        if (err) throw err;    
        console.log("Collection droped!");    
        db.close();  
    });
});

 
