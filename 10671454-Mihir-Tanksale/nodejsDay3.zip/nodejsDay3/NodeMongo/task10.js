//Using Nodejs Show all customers getting the Salary between 20000 and 40000
var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/";

MongoClient.connect(url, function(err, db) {
  if (err) throw err;
  var dbo = db.db("mydb2");
  var query = { $and: [ {
      "Salary": { $gt: 20000} 
    },
    {
       "Salary": {$lt: 40000}
    }
]}
  dbo.collection("customers").find(query).toArray(function(err, result) {
    if (err) throw err;
    console.log(result);
    db.close();
  });
});