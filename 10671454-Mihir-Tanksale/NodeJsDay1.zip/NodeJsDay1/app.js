console.log("Hello");
var d = new Date();
console.log(d);