var http = require('http');
var fs = require('fs');
var url = require('url');

http.createServer(function (req, res) 
{
    var q = url.parse(req.url,true);
    if (q.pathname === '/') 
    {
        fs.readFile('./index.html', function (err, html) {
            if (err) {
                res.write(err); 
            }       
            res.writeHeader(200, {"Content-Type": "text/html"});  
            res.write(html); 
            res.end();
        });
    } 
    
    else if (q.pathname === '/home') 
    {
      fs.readFile('./index.html', function (err, html) {
        if (err) {
            res.write(err); 
        }       
        res.writeHeader(200, {"Content-Type": "text/html"});  
        res.write(html); 
        res.end();
        });
    } 
    
    else if (q.pathname === '/registration') 
    {
      fs.readFile('./registration.html', function (err, html) {
        if (err) {
            res.write(err); 
        }       
        res.writeHeader(200, {"Content-Type": "text/html"});  
        res.write(html); 
        res.end();
        });
    } 
    
    else if(q.pathname === '/service'){
        fs.readFile('./service.html', function (err, html) {
            if (err) {
                res.write(err); 
            }       
            res.writeHeader(200, {"Content-Type": "text/html"});  
            res.write(html); 
            res.end();
            });
    }
    else if(q.pathname === '/contact'){
        fs.readFile('./contact.html', function (err, html) {
            if (err) {
                res.write(err);  
            }       
            res.writeHeader(200, {"Content-Type": "text/html"});  
            res.write(html); 
            res.end();
            });
    }
    
}).listen(5000);
