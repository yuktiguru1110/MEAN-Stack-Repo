var person = require('./data.js');
console.log(person.firstName+' '+person.lastName);