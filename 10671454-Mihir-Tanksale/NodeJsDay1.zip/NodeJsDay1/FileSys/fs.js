var fs = require('fs');
var path='./sample.txt';
console.log('before');
fs.readFile(path,function(err,file){
    console.log('during');
    console.log(''+file);
});
console.log('after');