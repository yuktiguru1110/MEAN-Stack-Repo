var express = require('express');

const bodyParser=require('body-parser');

var http = require('http');

var app = express();
app.use(bodyParser.urlencoded({extended:true}));
app.get('/calculator', function(req, res){

    res.sendFile(__dirname+"/calculator.html");  

  });

  app.post("/calculator", function(req, res) {

      console.log(req.body);

    //res.send('Calculation Ready Now!');

    let n1=Number(req.body.t1);

    let n2=Number(req.body.t2);

    let sum=n1+n2;

    res.send('<h1 style="text-align=center">Total Calculation:</h1>'+sum);

  })

// Create a server

http.createServer(app).listen(3000);