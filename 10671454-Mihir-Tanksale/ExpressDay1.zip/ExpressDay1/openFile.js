//create a server using nodejs and run on 5000
//redirect
const express = require('express')
const app = express()
const port = 5000

app.get('/about', (req, res) => {
  res.sendFile('F:/ExpressLab/about_test.html')
})

app.get('/registration', (req, res) => {
    res.sendFile('F:/ExpressLab/registration_test.html')
})

app.get('/contactus', (req, res) => {
    res.sendFile('F:/ExpressLab/contactus_test.html')
})

app.listen(port, () => {
    console.log(`Example app listening at http://localhost:${port}`)
})