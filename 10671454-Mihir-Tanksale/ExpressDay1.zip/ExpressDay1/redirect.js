//create a server using nodejs and run on 5000
//redirect
const express = require('express')
const app = express()
const port = 5000

app.get('/about', (req, res) => {
  res.send('about page')
})

app.get('/registration', (req, res) => {
    res.send('registration page')
})

app.get('/contactus', (req, res) => {
    res.send('contact us page')
})

app.listen(port, () => {
    console.log(`Example app listening at http://localhost:${port}`)
})