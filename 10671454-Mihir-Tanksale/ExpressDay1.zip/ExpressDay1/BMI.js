var express = require('express');

const bodyParser=require('body-parser');

var http = require('http');

var app = express();
app.use(bodyParser.urlencoded({extended:true}));
app.get('/bmi', function(req, res){

    res.sendFile(__dirname+"/BMI.html");  

  });

  app.post("/bmi", function(req, res) {

      console.log(req.body);

    //res.send('Calculation Ready Now!');

    let height=Number(req.body.t1);

    let weight=Number(req.body.t2);

    let bmi=weight/(height*height);

    res.send('<h1 style="text-align=center">BMI (Body Mass Index):</h1>'+bmi);

  })

// Create a server

http.createServer(app).listen(3000);