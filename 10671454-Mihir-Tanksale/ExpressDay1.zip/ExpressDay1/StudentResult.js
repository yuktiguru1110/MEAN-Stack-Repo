var express = require('express');

const bodyParser=require('body-parser');

var http = require('http');

var app = express();
app.use(bodyParser.urlencoded({extended:true}));
app.get('/studentresult', function(req, res){

    res.sendFile(__dirname+"/studentResult.html");  

  });

  app.post("/studentresult", function(req, res) {

      console.log(req.body);

    //res.send('Calculation Ready Now!');
    let maths = Number(req.body.maths);
    let english = Number(req.body.english);
    let science = Number(req.body.science);

    let total = maths+english+science;
    let percentage = (total/300)*100;
    let max = Math.max(maths,english,science);

    res.send('Total: '+total+'<br> Percentage: '+percentage+'<br> Max Marks: '+max);

  })

// Create a server

http.createServer(app).listen(3000);
