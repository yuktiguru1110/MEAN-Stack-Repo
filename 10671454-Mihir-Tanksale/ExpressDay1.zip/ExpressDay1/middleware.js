var express = require('express')
var app = express()
var requestDate = function (req, res, next) {    
    req.requestDate = Date()    
    next()
}
app.use(requestDate)
app.get('/', function (req, res) {    
    var responseMsg = '<div style="font-family: Verdana; color: coral;text-align: center; text-style: bold">Hello Learners!!</div><br>';     
    responseMsg += '<small>Request genrated at: ' + req.requestDate + '</small>'    
    res.send(responseMsg)
})
//PORT ENVIRONMENT VARIABLE
const port = process.env.PORT || 8080;
app.listen(port, () => console.log(`Listening on port ${port}..`));

