//create a server using nodejs and run on 5000
const express = require('express')
const app = express()
const port = 5000

app.get('/', (req, res) => {
  res.send('Hello World! using nodemon hello 5000')
})

app.listen(port, () => {
    console.log(`Example app listening at http://localhost:${port}`)
})