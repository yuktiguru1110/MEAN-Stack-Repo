//create a server using nodejs and run on 5000
const express = require('express')
const app = express()
const port = 5000

app.get('/about', (req, res) => {
  res.send('<div style="border-radius: 25px;background: #73AD21;padding: 20px; width: 200px;height: 150px;">about page</div>')
})


app.listen(port, () => {
    console.log(`Example app listening at http://localhost:${port}`)
})