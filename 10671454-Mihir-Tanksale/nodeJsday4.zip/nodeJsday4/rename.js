const fs = require('fs')

fs.rename('F:/NodeJs_practice/nodeJsday4/mihir1', 'F:/NodeJs_practice/nodeJsday4/rename', err => {

  if (err) {

    console.error(err)

    return

  }

  //done

})