setInterval(function(){
    console.log("Hello World");
},2000);