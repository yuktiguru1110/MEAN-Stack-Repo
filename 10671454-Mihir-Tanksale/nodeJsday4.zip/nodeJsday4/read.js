const fs = require('fs')
const path = require('path')
const folderPath = 'F:/NodeJs_practice/nodeJsday4/';
fs.readdirSync(folderPath)

fs.readdirSync(folderPath).map(fileName => {
  console.log( path.join(folderPath, fileName))
})

const isFile = fileName => {
    console.log( fs.lstatSync(fileName).isFile())
  }
  fs.readdirSync(folderPath).map(fileName => {
   return  path.join(folderPath, fileName)
  })
  .filter(isFile)