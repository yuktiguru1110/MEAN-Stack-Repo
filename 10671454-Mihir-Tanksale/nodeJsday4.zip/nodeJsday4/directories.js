const fs = require('fs');
const foldername = 'F:/NodeJs_practice/nodeJsday4/mihir';
try
{
    if(!fs.existsSync(foldername))
    {
        fs.mkdirSync(foldername);
    }
}
catch(err)
{
    console.error(err);       
}