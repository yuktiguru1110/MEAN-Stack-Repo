function jfun2() {
    window.open("test2.html", "_target", "width=200,height=100");
}