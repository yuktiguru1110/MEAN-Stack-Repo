function jfun1() {
    //alert("Before Action: Validation..");

    var name = frm1.t1.value;
    var designation = frm1.t2.value;
    if (name == "") {
        alert("Please Enter the name");
        frm1.t1.focus();
        return false;
    }
    else if (designation == "") {
        alert("Please Enter the designation");
        return false;
    }
    else {
        return true;
    }
}